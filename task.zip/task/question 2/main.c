#include <stdio.h>

int main() {
    int Number;
    scanf("%d", &Number);

    char op[3];
    while (1) {
        scanf("%s", op);
        if (op[0] == '+')
            Number++;
        else if (op[0] == '-')
            Number--;
        else
            break;
    }

    printf("%d\n", Number);
    return 0;
}