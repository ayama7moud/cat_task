#include <stdio.h>
#include <string.h>

char username[100], password[100];

void register_user() {
    printf("Enter username: ");
    scanf("%s", username);
    printf("Enter password: ");
    scanf("%s", password);

    FILE *file = fopen("user_data.txt", "w");
    fprintf(file, "%s\n%s", username, password);
    fclose(file);
}

void login_user() {
    char input_username[100], input_password[100];
    FILE *file = fopen("user_data.txt", "r");
    if (file) {
        fgets(username, 100, file);
        fgets(password, 100, file);
        fclose(file);

        username[strcspn(username, "\n")] = 0;
        password[strcspn(password, "\n")] = 0;

        printf("Enter username: ");
        scanf("%s", input_username);
        printf("Enter password: ");
        scanf("%s", input_password);

        if (strcmp(input_username, username) == 0 && strcmp(input_password, password) == 0) {
            printf("Login successful!\n");
        } else {
            printf("Invalid username or password.\n");
        }
    } else {
        printf("No user found.\n");
    }
}

int main() {
    int choice;
    while (1) {
        printf("1. Register\n2. Login\n3. Exit\n");
        scanf("%d", &choice);

        if (choice == 1) {
            register_user();
        } else if (choice == 2) {
            login_user();
        } else if (choice == 3) {
            break;
        } else {
            printf("Invalid choice.\n");
        }
    }
    return 0